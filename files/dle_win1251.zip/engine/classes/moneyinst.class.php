<?php

class MoneyInst
{
    private $config = array();
    private $errstr = '��� ������';
    private $fileTypes = array(
                          'exe' => '�� ���������',
                          'mp3' => 'audio',
                          'avi' => 'video',
                          'exe' => 'setup',
                          'pdf' => 'book',
                          'torrent' => 'torrent',
                          'rar' => 'archive',
                          'iso' => 'disk',
                          'jpg' => 'image');

    private $typesLists = array('archive' => '.7z.bz2.cab.deb.jar.rar.rpm.tar.zip.',
                    'video'   => ".3gp.aaf.asf.flv.mkv.mov.mpeg.qt.wmv.hdv.mpeg4.mp4.dvd.mxf.avi.",
                    'audio'   => ".aac.asf.cda.fla.mp3.ogg.wav.wma.cd.ac3.dts.flac.midi.mod.aud.",
                    'image'   => ".bmp.cpt.gif.jpeg.jpg.jp2.pcx.png.psd.tga.tpic.tiff.tif.wdp.hdp.cdr.svg.ico.ani.cur.xcf.",
                    'torrent' => ".torrent.",
                    'android' => ".apk.",
                    'book'    => ".ps.eps.pdf.doc.txt.rtf.djvu.opf.chm.sgml.xml.fb2.fb3.tex.lit.exebook.prc.epub.",
                    'disk'    => ".img.iso.nrg.mdf.uif.bin.cue.daa.pqi.cso.ccd.sub.wim.swm.rwm.");

    private $typesCodes = array('archive' => 1,
                    'video'   => 3,
                    'audio'   => 4,
                    'image'   => 5,
                    'torrent' => 6,
                    'android' => 7,
                    'book'    => 8,
                    'disk'    => 9,);

    private function setArray($config, $par)
    {
        if (!isset($config[$par]))
            $this->config[$par] = array();
        else
            $this->config[$par] = $config[$par];
    }

    private function setInt($config, $par)
    {
        if (!isset($config[$par]))
            $this->config[$par] = 0;
        else
            $this->config[$par] = intval($config[$par]);
    }

    private function setIntMax($config, $par, $max)
    {
        if (!isset($config[$par]))
            $this->config[$par] = 0;
        else {
            $num = intval($config[$par]);
            if ($num <= 0 or $num > $max)
                $this->config[$par] = 0;
            else
                $this->config[$par] = $num;
        }
    }

    private function setBool($config, $par)
    {
        if (isset($config[$par]) and $config[$par] === true)
            $this->config[$par] = true;
        else
            $this->config[$par] = false;
    }

    private function setString($config, $par)
    {
        if (isset($config[$par]))
            $this->config[$par] = $config[$par];
        else
            $this->config[$par] = '';
    }

    // loads configuration
    public function loadConfig()
    {
        if (is_file(moneyinst_conffile)) {
            include moneyinst_conffile;
        }
        // sid
        $this->setInt($config, 'sid');
        // hosts
        $this->setArray($config, 'hosts');
        // groups
        $this->setArray($config, 'groups');
        // state
        $this->setBool($config, 'on');
        // attachments
        $this->setBool($config, 'attach');
        // news
        $this->setBool($config, 'news');
        // static
        $this->setBool($config, 'static');
        // file type
        $this->setString($config, 'filetype');
        //ext
        $this->setArray($config, 'file_extensions');
    }

    // saves configuration
    public function saveConfig($on, $sid, $hosts, $groups, $attach, $news, $static, $filetype, $file_extensions)
    {
        // parsing int
        $psid = intval($sid);
        $pfiletype = $filetype;
        // parsing hosts
        $phosts = array();
        $tmp_hosts = explode("\n", $hosts);
        foreach ($tmp_hosts as $host)
            if (($tmp = trim($host)) != '')
                $phosts[] = str_replace('\'', '\\\'', str_replace('\\', '\\\\', $tmp));
        $phosts = array_unique($phosts);
        // parsing groups
        $pgroups = array();
        if (isset($groups))
            foreach ($groups as $group)
                $pgroups[] = intval($group);
        $pgroups = array_unique($pgroups);
        // parsing strings
        $file_extensions = str_replace(' ', '', $file_extensions);
        $file_extensions = str_replace('\'', '\\\'', str_replace('\\', '\\\\', $file_extensions));
        $pfile_extensions = explode(',', $file_extensions);
        $str = '<?php

$config = array(
    \'on\' => ' . ($on ? 'true' : 'false') . ',
    \'attach\' => ' . ($attach ? 'true' : 'false') . ',
    \'news\' => ' . ($news ? 'true' : 'false') . ',
    \'static\' => ' . ($static ? 'true' : 'false') . ',
    \'sid\' => ' . $psid . ',
    \'hosts\' => array(';
        $tmp = '';
        foreach ($phosts as $host)
            $tmp .= '
        \'' . $host . '\',';
        $str .= substr($tmp, 0, -1) . '
    ),
    \'groups\' => array(';
        $tmp = '';
        foreach ($pgroups as $group)
            $tmp .= '
        ' . $group . ',';
        $str .= substr($tmp, 0, -1) . '
    ),
    \'filetype\' => \'' . $pfiletype . '\',
    \'file_extensions\' => array(';
        $tmp = '';
        foreach ($pfile_extensions as $ext)
            $tmp .= '
        \'' . $ext . '\',';
        $str .= substr($tmp, 0, -1) . '
    )
);';
        if (false === file_put_contents(moneyinst_conffile, $str)) {
            $this->errstr = '�� ���� �������� ������������ � ���� "' . realpath(moneyinst_conffile) . '"';
            return false;
        }
        return true;
    }

    // return whether moneyinst replacement allowed or not
    public function isAllowed($url, $group, $isattach = false, $name = null)
    {
        if (!isset($this->config))
            return false;
        if (!$this->config['on'])
            return false;
        if (!$isattach and count($this->config['hosts'])) {
            if (false === preg_match('@^(?>https?://)?(.*?)(?>/|$)@', $url, $matches)) {
                return false;
            }
            if (!in_array($matches[1], $this->config['hosts']))
                return false;
        }
        if (!in_array($group, $this->config['groups']))
            return false;
        if (count($this->config['file_extensions'])){
          if (preg_match('/\.([\w]+)$/', $name , $matches)){
            if (!in_array($matches[1], $this->config['file_extensions'])){
              return false;
            }
          }else{
            return false;
          }
        }
        return true;
    }

    // returns moneyinst url
    public function createUrl($url, $group, $name = null, $size = null, $isattach = false)
    {
        $url = trim($url);
        if (substr ($url, 0, 4) !== 'http') {
            $protocol = (isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS'])) ? 'https://' : 'http://';
            if (substr ($url, 0, 1) == '/'){
                $url = $protocol . $_SERVER['SERVER_NAME'] . $url;
            }else{
                $url = $protocol . $_SERVER['SERVER_NAME'] . '/' . $url;
            }
        }
        if (empty($name)){
          if (preg_match('/^http:\/\/.+\/([^\/]+)\/?$/i', $url , $matches)){
            $name = $matches[1];
          }else{
            return '';
          }
        }
        if (preg_match('/\.(.+)$/', $name, $matches)){
          $ext = $matches[1];
        }else{
          $ext = $this->config['filetype'];
          $name .= '.' . $ext;
        }
        if (!$this->isAllowed($url, $group, $isattach, $name)) return '';
        $str = 'class="mi-download-link" download_url="' . base64_encode($url) . '" ';
        $str .= 'download_name="' . base64_encode($name) . '" ';
        $str .= 'download_type="' . base64_encode($this->findCodeByExt('.' . $ext . '.')) . '" ';
        if (isset($size))
            $str .= 'download_size="' . base64_encode($size) . '" ';
        if ($sid = $this->getSid())
            $str .= 'download_sid="' . base64_encode($sid) . '" ';
        return $str;
    }

  public function replaceLinks($str, $group)
  {
    $resstr = '';
    $pos2 = 0;
    //@todo save link attributes
    while (false !== $pos = strpos($str, 'href="', $pos2)) {
      $resstr .= substr($str, $pos2, $pos - $pos2);
      if (false === $pos2 = strpos($str, '"', $pos + 6)) {
        $pos2 = $pos;
        break;
      }
      $url = substr($str, $pos + 6, $pos2 - $pos - 6);
      $resstr .= $this->createUrl($url, $group) . substr($str, $pos, $pos2 - $pos);
    }
    $resstr .= substr($str, $pos2);
    return $resstr;
  }

  function findCodeByExt($ext){
    foreach($this->typesLists as $key => $list){
      if (strpos($list, $ext) !== false){
        return $this->typesCodes[$key];
      }
    }
    return 2;
  }

    // returns error string
    public function error()
    {
        return $this->errstr;
    }

    // return list of available file types
    public function getFileTypes()
    {
        return $this->fileTypes;
    }

    // returns sid
    public function getSid()
    {
        return $this->config['sid'];
    }

    // returns file type
    public function getFileType()
    {
        return $this->config['filetype'];
    }

    // returns hosts
    public function getHosts()
    {
        return $this->config['hosts'];
    }

    // returns groups
    public function getGroups()
    {
        return $this->config['groups'];
    }

    // returns file name
    public function getFileName()
    {
        return $this->config['filename'];
    }

    public function getFileExtensions()
    {
        return $this->config['file_extensions'];
    }
    // returns state
    public function isOn()
    {
        return $this->config['on'];
    }

    // returns attachments
    public function isAttachments()
    {
        return $this->config['attach'];
    }

    // returns news
    public function isNews()
    {
        return $this->config['news'];
    }

    // returns static
    public function isStatic()
    {
        return $this->config['static'];
    }

    // returns file name type
    public function isFileNameType()
    {
        return $this->config['filenametype'];
    }

}