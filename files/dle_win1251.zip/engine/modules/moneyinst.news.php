<?php

include_once('moneyinst.php');

$row['short_story'] = $_moneyinst->replaceLinks($row['short_story'], $member_id['user_group']);
$row['full_story'] = $_moneyinst->replaceLinks($row['full_story'], $member_id['user_group']);