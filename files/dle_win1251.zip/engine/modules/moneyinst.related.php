<?php

include_once('moneyinst.php');

$related['short_story'] = $_moneyinst->replaceLinks($related['short_story'], $member_id['user_group']);
$related['full_story'] = $_moneyinst->replaceLinks($related['full_story'], $member_id['user_group']);