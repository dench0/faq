<?php

function is_ajax() {
  return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

function moneyinst_get_domain(){
  $cacheTime = 60;
  $cacheFile = '/tmp/moneyinst-domain.tmp';
  $domain = FALSE;
  clearstatcache();
  if (@file_exists($cacheFile)) {
    $tmp = @file_get_contents($cacheFile);
    if ($tmp !== false) {
        $domain = $tmp;
    }
    $mTime = @filemtime($cacheFile);
    if ((time() - $mTime) > $cacheTime || $mTime == FALSE) {
      $domain = FALSE;
    }
  }
  if (!$domain){
    $domain = @file_get_contents('http://api.moneyinst.com/api/frontend_domain/');
    if (!filter_var($domain, FILTER_VALIDATE_URL)){
      return FALSE;
    }
    $fp = @fopen($cacheFile, "w");
    if (flock($fp, LOCK_EX)){ 
      ftruncate($fp, 0);
      fwrite($fp, $domain);
      fflush($fp);  
      flock($fp, LOCK_UN); 
    }
  }    
  return $domain;
}

if (!is_ajax()){
  die;
}

$domain = moneyinst_get_domain();
if (!$domain){
  die;
}

$apiUrl = $domain . '/api/download_url/' . base64_decode($_POST['type']) . '/' . base64_decode($_POST['sid']) . '/' . base64_decode($_POST['name']) . '/' . base64_decode($_POST['url']);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl); 
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); 
curl_setopt($ch, CURLOPT_TIMEOUT, 3); 
$url = curl_exec($ch);
curl_close($ch);   
if (!filter_var($url, FILTER_VALIDATE_URL)){
  die;
}
header('Content-Type: application/json');
echo json_encode(array('url' => $url, 'api_url' => $apiUrl), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
die;
?>