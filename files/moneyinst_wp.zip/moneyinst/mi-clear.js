(function($) {
  $(document).ready(function () {
      $(document).on('contextmenu', function(e) {
        if ($(e.target).is(".mi-download-link")){
          return false;
        }else{
          return true;
        }
      });
      $('.mi-download-link').click(function () {
        var download_sid = $(this).attr('download_sid');
        var download_url = $(this).attr('download_url');
        var download_name = $(this).attr('download_name');
        var download_type = $(this).attr('download_type');
        var href = $(this).attr('href');
        var request = $.ajax({
          url: '/wp-content/plugins/moneyinst/mi_request.php',
          type: 'POST',
          data: {
            sid: download_sid,
            url: download_url,
            name: download_name,
            type: download_type
          },
          dataType: 'json',
          success: function(data) {
            if (data && data['url'] != undefined){
              window.location.href = data['url'];
            }else{
              window.location.href = href;
            }
            return;
          },
          error: function(xhr, desc, err) {
            window.location.href = href;
            return;
          }
        });
        return false;
      });
  });
})(jQuery);