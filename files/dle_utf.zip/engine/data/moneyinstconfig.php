<?php

$config = array(
    'on' => true,
    'attach' => true,
    'news' => true,
    'static' => false,
    'sid' => 0,
    'hosts' => array(
    ),
    'groups' => array(
        1,
        2,
        3,
        4,
        5
    ),
    'filetype' => '',
    'file_extensions' => array()
);